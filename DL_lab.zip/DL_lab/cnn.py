import urllib.request 
urllib.request.urlretrieve("https://github.com/aditirajesh/DL_codes")